<link rel="stylesheet" href="styles.css">

<div id="video" class="video">
    <video autoplay muted loop id="video">
        <source src="media/video.mp4" type="video/mp4">
    </video>

    <center>
        <p>
            <br>
            <h1>Comic-Blog</h1>
            <br>
            <h2>Eine Website zum Sammeln und Präsentieren von Comics</h2>
  	        <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <h2>viel Spaß beim Lesen!</h2>
        </p>
    </center>
</div>

<br>