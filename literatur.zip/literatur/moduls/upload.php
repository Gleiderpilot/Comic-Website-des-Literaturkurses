<link rel="stylesheet" href="styles.css">

    <?php
        if ($angemeldet) {
    ?>
    <center>
        <div id="upload" class="upload">

        <h3>
            Trau dich und lade auch etwas hoch!
        </h3>
    
        <br>

        <?php
            if (!isset($_POST['ak'])){
                echo "
                <form action='index.php' method='post' enctype='multipart/form-data'>
                    <input type='file' name='file'>
                    <input type='hidden' name='ak' value='1'>
                    <br>
                    <br>
                    <button type='submit' name='submit' value='1'>Submit File</button>
                </form>";

            }elseif ($check = check_file()){
                echo $check;
            }

            function check_file()
                {
                    $fileName = $_FILES['file']['name'];
                    $fileTmpName = $_FILES['file']['tmp_name'];
                    $fileSize = $_FILES['file']['size'];
                    $fileError = $_FILES['file']['error'];
                    $fileType = $_FILES['file']['type'];

                    $fileExt = explode(".", $fileName);
                    $fileActualExt = strtolower(end($fileExt));

                    $allowed = array("jpg", "jpeg", "png", "pdf");

                    if (in_array($fileActualExt, $allowed)) {

                        if ($fileError === 0) {

                            if ($fileSize < 1000) {

                                $fileNameNew = uniqid('', true) . "." . $fileActualExt;
                                $fileDestination = "uploads/" . $fileNameNew;
                                move_uploaded_file($fileTmpName, $fileDestination);
                                #header("Location: index.php?uploadsuccess");
                            } else {
                                return "Die Datei ist zu groß.";
                            }
                        } else {
                            return "Es gab einen Fehler beim Upload. Versuch's nochmal.";
                        }
                    } else {
                        return "Format nicht zulässig.";
                    }
                        return "Erfolgreich hochgeladen...";
                }
        ?>
        <br>
    </center>

    <?php
        } else {
    ?>
            <center>
                <h3>
                    Um einen Comic hochzuladen, musst du dich einlogen.
                </h3>
            </center>
    <?php
        }
    ?>

</div>