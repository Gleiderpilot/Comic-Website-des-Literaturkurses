<div id="bewertungen" class="bewertungen">
  <div id="list" class="list">
    <center>
      <h2> Folgende Bewertungen wurden schon abgegeben: </h2>
    </center>
  </div>

    <br>

    <p>
      <a class="links" href="#5_Sterne">⭐⭐⭐⭐⭐</a><br>
      <!--<a class="links" href="#4_Sterne">⭐⭐⭐⭐ ☆</a><br>
      <a class="links" href="#3_Sterne">⭐⭐⭐ ☆ ☆</a><br>
      <a class="links" href="#2_Sterne">⭐⭐ ☆ ☆ ☆</a><br>
      <a class="links" href="#1_Sterne">⭐ ☆ ☆ ☆ ☆</a><br>
      <a class="links" href="#0_Sterne">‎ ☆ ☆ ☆ ☆ ☆</a><br>-->
    </p>

  <h3 id="5_Sterne"> 5_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
        <!--hier stehe, wenn vorhanden das top-review-->
      </p>
  <!--
  <div id="comments" class="bewertungen">
    <h3 id="4_Sterne"> 4_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>
  <div id="comments" class="bewertungen">
    <h3 id="3_Sterne"> 3_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>
  <div id="comments" class="bewertungen">
    <h3 id="2_Sterne"> 2_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>
  <div id="comments" class="bewertungen">
    <h3 id="1_Sterne"> 1_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>
  <div id="comments" class="bewertungen">
    <h3 id="0_Sterne"> 0_Sterne: </h3>
      <p>
        Leider hat noch keiner ein review hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>-->
</div>
