<link rel="stylesheet" href="styles.css">
<?php
    include 'moduls/header.php';
?>

<h1>Support</h1>
    
    <form action="support.php" method="post">
        <label for="message">Support-Nachricht:</label><br>
        <textarea id="message" name="message" rows="4" cols="50"></textarea><br><br>
        <input type="submit" value="Absenden">
    </form>

<?php
    include '../moduls/footer.php';
?>