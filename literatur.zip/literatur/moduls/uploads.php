<?php
	$file=$_FILES["file"];
	move_upload_file($file["tmp_name"], "uploads/" . $file["name"]);
	header("location: index.php");
?>