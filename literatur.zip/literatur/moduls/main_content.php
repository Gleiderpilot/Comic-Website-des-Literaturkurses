<div id="main_content" class="main_content">
  <div id="list" class="list">
    <center>
      <h2> Texte in folgenden Genre stehen zur Verfügung: </h2>
    </center>
      <p>
        <a class="links" href="#zurklassik">- Klassik</a><br>
        <a class="links" href="#zurkritik">- Kritik</a><br>
        <a class="links" href="#zursf">- Sci-Fi</a><br>
        <a class="links" href="#zurfantasy">- Fantasy</a><br>
      </p>
  </div>

    <br>

  <div id="comics" class="comics">
    <h3 id="zurklassik"> Klassik: </h3>
      <p>
        Leider hat noch keiner einen Comic in diesem Genre hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>

    <h3 id="zurkritik"> Kritik: </h3>
      <p>
        Leider hat noch keiner einen Comic in diesem Genre hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>

    <h3 id="zursf"> Sci-Fi: </h3>
      <p>
        Leider hat noch keiner einen Comic in diesem Genre hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>

    <h3 id="zurfantasy"> Fantasy: </h3>
      <p>
        Leider hat noch keiner einen Comic in diesem Genre hochgeladen :( <br>
        Aber du kannst das ändern!
      </p>
  </div>
</div>