<?php
    include 'moduls/icons.php';
?>

<form action="#" method="post">
    <table>
        <tr>
            <td>
                <a href="../index.php?do=0">
                  <span class="icon">
                    <ion-icon name="home-outline"></ion-icon>
                  </span>
                  <span class="text">Home</span>
                </a>
            </td>
            <td>
                <a href="../moduls/login.php?do=1">
                  <span class="icon">
                    <ion-icon name="log-in-outline"></ion-icon>
                  </span>
                  <span class="text">Login</span>
                </a>
            </td>
            <td>
              <a href="../moduls/upload.php?do=2">
                <span class="icon">
                  <ion-icon name="cloud-upload-outline"></ion-icon>
                </span>
                <span class="text">Upload</span>
              </a>
            </td>
            <td>
              <a href="../moduls/support.php?do=3">
                <span class="icon">
                  <ion-icon name="help-circle-outline"></ion-icon>
                </span>
                <span class="text">Support</span>
              </a>
            </td>
        </tr>
    </table>

    <input type="submit" value="Senden">
</form>

<!-- $laenge=$_POST['laenge'];
$breite=$_POST['breite'];
$flaeche=2*$laenge*$breite;
//print_r($_POST);-->